#include "NRF24L01_radio.h"


void NRF24L01_radio::setupTransmitter()
{

}


void NRF24L01_radio::setupReceiver()
{

}


void NRF24L01_radio::transmit()
{

}


void NRF24L01_radio::receive()
{

}


void NRF24L01_radio::sortOutgoingData(uint8_t id)
{

}


void NRF24L01_radio::sortIncomingData()
{

}